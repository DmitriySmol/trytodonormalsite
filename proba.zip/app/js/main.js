$(document).ready(function () {
	console.log('Я на главной страничке');
});
