Как установить мой проект

1. git clone git.____url в папку ___
2. cd в папку ___
3. bower i 
4. npm i 
5. Запустить gulp